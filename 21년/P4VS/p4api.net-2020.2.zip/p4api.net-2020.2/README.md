[![Support](https://img.shields.io/badge/Support-Official-green.svg)](mailto:support@perforce.com)

# p4api.net
P4API.NET is a wrapper for the P4 C++ API in C#.
