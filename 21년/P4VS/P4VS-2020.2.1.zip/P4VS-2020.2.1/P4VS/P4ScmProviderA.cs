﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Perforce.P4;

namespace Perforce.P4Vs
{
    class P4ScmProvider
    {
    }
}
